#!/bin/bash
cd /home/pi/alexa-avs-sample-app/samples
cd companionService && sudo npm start
