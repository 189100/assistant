#!/bin/bash
cd /home/pi/alexa-avs-sample-app/samples
cd javaclient && sudo mvn exec:exec
